<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/index.html">
<title></title>
<script language="javascript">
    window.location.href = "admin/index.php"
</script>
</head>
<body>
</body>
</html>
